#!/bin/bash

# File lưu trữ key
KEY_FILE="keys.enc"
ADMIN_PASSWORD="Nongtrieuthaidz"  # Đặt mật khẩu cho admin

# Hàm kiểm tra key
check_key() {
    read -sp "Nhập key để truy cập: " USER_KEY
    echo

    # Lặp qua từng dòng trong file key
    while IFS=',' read -r ENCRYPTED_KEY EXPIRATION_DATE; do
        DECRYPTED_KEY=$(echo "$ENCRYPTED_KEY" | openssl enc -aes-256-cbc -d -a -pass pass:"$ADMIN_PASSWORD" 2>/dev/null)

        if [[ "$DECRYPTED_KEY" == "$USER_KEY" ]]; then
            CURRENT_DATE=$(date +%d-%m-%Y)
            if [[ "$CURRENT_DATE" > "$EXPIRATION_DATE" ]]; then
                echo "Key '$USER_KEY' đã hết hạn."
            else
                echo "Truy cập được phép với key '$USER_KEY'. Ngày hết hạn: $EXPIRATION_DATE" && tun
            fi
            return
        fi
    done < "$KEY_FILE"

    echo "Key '$USER_KEY' không hợp lệ."
}

# Kiểm tra key
check_key