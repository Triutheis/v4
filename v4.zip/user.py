import json
from cryptography.fernet import Fernet
from datetime import datetime

class UserAccess:
    def __init__(self, key_file='keys.json'):
        self.key_file = key_file
        self.load_keys()

    def load_keys(self):
        try:
            with open(self.key_file, 'r') as f:
                self.keys = json.load(f)
        except FileNotFoundError:
            self.keys = {}

    def access_with_key(self, identifier, key):
        if identifier not in self.keys:
            print("Identifier not found.")
            return False
        
        key_data = self.keys[identifier]
        if key_data['key'] != key:
            print("Invalid key.")
            return False
        
        expiration_date = datetime.fromisoformat(key_data['expiration'])
        if datetime.now() >= expiration_date:
            print("Key has expired.")
            return False
        
        print("Access granted.")
        return True

if __name__ == '__main__':
    user = UserAccess()
    identifier = input("Enter identifier: ")
    key = input("Enter key: ")
    user.access_with_key(identifier, key)