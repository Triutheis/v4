import json
from cryptography.fernet import Fernet
from datetime import datetime, timedelta

class KeyManager:
    def __init__(self, key_file='keys.json'):
        self.key_file = key_file
        self.load_keys()

    def load_keys(self):
        try:
            with open(self.key_file, 'r') as f:
                self.keys = json.load(f)
        except FileNotFoundError:
            self.keys = {}

    def save_keys(self):
        with open(self.key_file, 'w') as f:
            json.dump(self.keys, f)

    def generate_key(self):
        return Fernet.generate_key().decode()

    def add_key(self, identifier, days_valid):
        if identifier in self.keys:
            print(f"Key for {identifier} already exists.")
            return
        
        key = self.generate_key()
        expiration_date = (datetime.now() + timedelta(days=days_valid)).isoformat()
        self.keys[identifier] = {'key': key, 'expiration': expiration_date}
        self.save_keys()
        print(f"Key for {identifier} added with expiration date: {expiration_date}.")

    def list_keys(self):
        print("Current keys:")
        for identifier, data in self.keys.items():
            print(f"{identifier}: {data['key']} (Expires: {data['expiration']})")

    def delete_key(self, identifier):
        if identifier in self.keys:
            del self.keys[identifier]
            self.save_keys()
            print(f"Key for {identifier} deleted.")
        else:
            print(f"Không tìm thấy chìa khóa nào cho {identifier}.")

    def update_key(self, identifier, days_valid):
        if identifier in self.keys:
            new_key = self.generate_key()
            expiration_date = (datetime.now() + timedelta(days=days_valid)).isoformat()
            self.keys[identifier] = {'key': new_key, 'hết hạn': expiration_date}
            self.save_keys()
            print(f"Key {identifier} được cập nhật với ngày hết hạn mới: {expiration_date}.")
        else:
            print(f"Không tìm thấy chìa khóa nào cho {identifier}.")

    def is_key_valid(self, identifier):
        if identifier in self.keys:
            expiration_date = datetime.fromisoformat(self.keys[identifier]['expiration'])
            return datetime.now() < expiration_date
        return False

if __name__ == '__main__':
    manager = KeyManager()
    while True:
        print("\n1. Add Key\n2. List Keys\n3. Delete Key\n4. Update Key\n5. Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            identifier = input("Nhập mã định danh cho khóa: ")
            days_valid = int(input("Nhập số ngày key hợp lệ: "))
            manager.add_key(identifier, days_valid)
        elif choice == '2':
            manager.list_keys()
        elif choice == '3':
            identifier = input("Nhập mã định danh để xóa khóa: ")
            manager.delete_key(identifier)
        elif choice == '4':
            identifier = input("Nhập mã định danh để cập nhật khóa: ")
            days_valid = int(input("Nhập số ngày key mới có hiệu lực: "))
            manager.update_key(identifier, days_valid)
        elif choice == '5':
            break
        else:
            print("Tùy chọn không hợp lệ, vui lòng thử lại.")