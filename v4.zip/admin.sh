#!/bin/bash

# File lưu trữ key
KEY_FILE="keys.enc"
ADMIN_PASSWORD="nongtrieuthaidz"  # Đặt mật khẩu cho admin

# Hàm mã hóa key
encrypt_key() {
    echo "$1" | openssl enc -aes-256-cbc -a -salt -pass pass:"$ADMIN_PASSWORD"
}

# Hàm thêm key
add_key() {
    read -p "Nhập key mới: " NEW_KEY

    # Kiểm tra key không được để trống
    if [[ -z "$NEW_KEY" ]]; then
        echo "Key không được để trống. Vui lòng nhập lại."
        return
    fi

    read -p "Nhập ngày hết hạn (YYYY-MM-DD): " EXPIRATION_DATE

    # Kiểm tra định dạng ngày
    if ! date -d "$EXPIRATION_DATE" >/dev/null 2>&1; then
        echo "Định dạng ngày không hợp lệ."
        return
    fi

    # Mã hóa key và lưu vào file
    ENCRYPTED_KEY=$(encrypt_key "$NEW_KEY")
    echo "$ENCRYPTED_KEY,$EXPIRATION_DATE" >> "$KEY_FILE"
    echo "Key đã được thêm thành công."
}

# Hàm liệt kê key
list_keys() {
    echo "Danh sách các key hiện tại:"
    while IFS=',' read -r ENCRYPTED_KEY EXPIRATION_DATE; do
        DECRYPTED_KEY=$(echo "$ENCRYPTED_KEY" | openssl enc -aes-256-cbc -d -a -pass pass:"$ADMIN_PASSWORD" 2>/dev/null)
        echo "Key: $DECRYPTED_KEY, Hết hạn: $EXPIRATION_DATE"
    done < "$KEY_FILE"
}

# Nhập mật khẩu admin
read -sp "Nhập mật khẩu admin: " PASSWORD
echo
if [[ "$PASSWORD" == "$ADMIN_PASSWORD" ]]; then
    echo "1. Thêm key"
    echo "2. Liệt kê key"
    read -p "Chọn một tùy chọn: " OPTION

    case $OPTION in
        1)
            add_key
            ;;
        2)
            list_keys
            ;;
        *)
            echo "Tùy chọn không hợp lệ."
            ;;
    esac
else
    echo "Mật khẩu không chính xác."
fi